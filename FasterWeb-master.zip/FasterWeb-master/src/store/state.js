export default {
    backButton: false,
    token:null,
    user: null

}
